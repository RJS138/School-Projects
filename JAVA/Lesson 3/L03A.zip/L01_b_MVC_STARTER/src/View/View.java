package View;

import Model.Model;
import Model.Person;
import java.util.ArrayList;

public class View
{

    public View()
    {

    }
    public void basicDisplay(String s)
    {
    System.out.print(s + "\n");
    }
    public void basicDisplay(ArrayList<String> arr)
    {
        for(String data : arr){
            System.out.print(data + " ");
        }
        System.out.print("\n");
    }

}
