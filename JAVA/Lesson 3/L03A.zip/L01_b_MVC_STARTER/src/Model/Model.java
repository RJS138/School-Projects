package Model;

import java.util.ArrayList;

public class Model
{
    private ArrayList <TableMember> members = new ArrayList <TableMember> ();
public Model()
{
    loadData();
}

 private void loadData() {
    Height h1 = new Height (5, 2);
    Height h2 = new Height (5, 9);
    Height h3 = new Height (6, 1);
    Height h4 = new Height (6, 0);
    FootballPlayer p1 = new FootballPlayer(2, "S", "Marcus Allen", 200, "Upper Marlboro, Md.", "Dr. Henry A. Wise, Jr.", h1);
    FootballPlayer p2 = new FootballPlayer(37, "CB","Kyle Alston", 180, "Robbinsville, N.J.", "Robbinsville", h2);
    FootballPlayer p3 = new FootballPlayer(28, "S","Troy Apke", 220, "Mt. Lebanon, Pa.", "Mount Lebanon", h3);
    FootballPlayer p4 = new FootballPlayer(35, "LB", "Matthew Baney", 225, "State College, Pa.", "State College", h4);
    FootballPlayer p5 = new FootballPlayer(); 
    getMembers().add(p1);
    getMembers().add(p2);
    getMembers().add(p3);  
    getMembers().add(p4);
    getMembers().add(p5);
}

    /**
     * @return the members
     */
    public ArrayList <TableMember> getMembers() {
        return members;
    }

    /**
     * @param members the members to set
     */
    public void setMembers(ArrayList <TableMember> members) {
        this.members = members;
    }

}